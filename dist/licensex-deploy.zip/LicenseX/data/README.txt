LicenseX stores your licenses here. Keep this folder (or use Settings -> Backup in the admin).
